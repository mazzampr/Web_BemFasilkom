"use strict";
exports.id = 717;
exports.ids = [717];
exports.modules = {

/***/ 4717:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonOutline)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);




function ButtonOutline({
  content,
  width,
  bismitMode
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: `${bismitMode ? 'bg-transparent' : 'bg-red-600 bg-gradient-cust-orange2 p-[.1rem]'} lg:flex group rounded-[10px] w-fit  lg:m-auto `,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
        href: `/event`,
        className: `group from-[#FA6D01] to-[#FA870199] via-yellow-500 relative overflow-hidden md:w-full ${width != '' ? width : ' lg:w-[13rem]'} flex justify-center py-[.35rem] font-medium 
                        text-sm rounded-[9px]  ${bismitMode ? 'bg-transparent group-hover:bg-gradient-to-r outline outline-orange-300 py-[.6rem]' : 'bg-white group-hover:bg-gradient-to-r'} cursor-pointer`,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
          className: `pr-4 lg:pr-2 lg:pl-2  pl-3  ${bismitMode ? 'lg:text-white text-base' : 'text-black text-sm'}`,
          children: content
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          children: !bismitMode ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
            viewBox: "0 0 46 16",
            height: "7",
            width: "25",
            xmlns: "http://www.w3.org/2000/svg",
            id: "arrow-horizontal",
            className: "-translate-x-1 fill-slate-700 mt-2 transition-all duration-300 group-hover:translate-x-[.2rem] group-hover:scale-x-95",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
              transform: "translate(30)",
              d: "M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z",
              "data-name": "Path 10",
              id: "Path_10"
            })
          }) : null
        })]
      })
    })
  });
}

/***/ })

};
;