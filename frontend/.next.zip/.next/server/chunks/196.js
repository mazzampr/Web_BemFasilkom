"use strict";
exports.id = 196;
exports.ids = [196];
exports.modules = {

/***/ 3175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ DocumentHead)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);



const DocumentHead = ({
  pageTitle
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
      rel: "shortcut icon",
      href: "/bem-fasilkom-logo.png",
      type: "image/x-icon"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
      children: [pageTitle ? `${pageTitle} | ` : null, " ", 'BEM FASILKOM UPN "Veteran" Jawa Timur']
    })]
  });
};

/***/ }),

/***/ 7687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T5": () => (/* binding */ API_URL),
/* harmony export */   "Yi": () => (/* binding */ EMAIL_BEM)
/* harmony export */ });
/* unused harmony export SELF_URL */
// export const API_URL = "https://web-bem-testing.herokuapp.com";
// export const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_URL = "http://localhost:1337"; // export const SELF_URL = "https://website-bem.vercel.app";

const SELF_URL = process.env.SELF_URL;
const EMAIL_BEM = "bem.fasilkom@upnjatim.ac.id";

/***/ }),

/***/ 7359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ NavbarBackgroundContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const NavbarBackgroundContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
  navbarBackgroundColor: "#fff",
  setNavbarBackgroundColor: () => {}
});

/***/ }),

/***/ 2698:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ useDarkNavLinks)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_navbar_background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7359);


const useDarkNavLinks = () => {
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_contexts_navbar_background__WEBPACK_IMPORTED_MODULE_1__/* .NavbarBackgroundContext */ .s).setNavbarBackgroundColor("#fff");
};

/***/ })

};
;