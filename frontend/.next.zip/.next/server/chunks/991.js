exports.id = 991;
exports.ids = [991];
exports.modules = {

/***/ 761:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uK": () => (/* binding */ setStatePageVisit),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export pageVisitSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const pageVisitSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'pageVisit',
  initialState: {
    value: ''
  },
  reducers: {
    setStatePageVisit: (state, {
      payload
    }) => {
      state.value = payload.page;
    }
  }
});
const {
  setStatePageVisit
} = pageVisitSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (pageVisitSlice.reducer);

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;