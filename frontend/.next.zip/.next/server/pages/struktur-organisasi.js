"use strict";
(() => {
var exports = {};
exports.id = 270;
exports.ids = [270];
exports.modules = {

/***/ 7687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T5": () => (/* binding */ API_URL),
/* harmony export */   "Yi": () => (/* binding */ EMAIL_BEM)
/* harmony export */ });
/* unused harmony export SELF_URL */
// export const API_URL = "https://web-bem-testing.herokuapp.com";
// export const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_URL = "http://localhost:1337"; // export const SELF_URL = "https://website-bem.vercel.app";

const SELF_URL = process.env.SELF_URL;
const EMAIL_BEM = "bem.fasilkom@upnjatim.ac.id";

/***/ }),

/***/ 2420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ struktur_organisasi),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: external "react-tabs"
const external_react_tabs_namespaceObject = require("react-tabs");
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(7687);
;// CONCATENATED MODULE: ./components/strukturOrganisasi/cardAnggota.tsx





function cardAnggota({
  nama,
  jabatan,
  jurusan,
  linkedin,
  foto,
  angkatan
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
    className: "card hover:translate-y-[-10px] transition-all overflow-hidden flex flex-col gap-7 lg:gap-6 rounded-md w-[80%] min-[550px]:w-[40%] min-[730px]:w-[40%] lg:h-[30%] lg:w-[250px] border-2 bg-pastel pb-4 box-border drop-shadow",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full h-[40%] flex flex-col flex-wrap gap-0 items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("figure", {
        className: "w-full h-full",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          className: "object-cover rounded-t-xl",
          src: `${constants/* API_URL */.T5}${foto}`,
          width: 400,
          height: 400,
          alt: "Card Image"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("figcaption", {
        className: "text-typedBlue text-center lg:text-sm",
        children: jabatan
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col flex-wrap w-full items-center gap-2",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
        className: "nama flex items-center leading-6 text-base font-bold text-typedBlue text-center mb-4 h-[1rem] px-2",
        children: nama
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "text-[#6C6C6C]",
        children: [jurusan, " - ", angkatan]
      }), /*#__PURE__*/jsx_runtime_.jsx("figure", {
        className: "hover:scale-[1.1] transition-all hover:animate-bounce cursor-pointer",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: linkedin,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: '/icons/vectorLinkedin.svg',
            width: 20,
            height: 20,
            alt: "Linkedin"
          })
        })
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./components/Assets/Proker.tsx


function Proker({
  prokerName
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "w-[40%] h-fit px-4 py-2 bg-pastel rounded-md text-center hover:scale-[1.1] transition-all",
    children: /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: "",
      children: prokerName
    })
  });
}
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./store/pageVisitSlices.ts
var pageVisitSlices = __webpack_require__(761);
// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(9015);
// EXTERNAL MODULE: external "gsap/dist/ScrollTrigger"
var ScrollTrigger_ = __webpack_require__(1498);
;// CONCATENATED MODULE: ./pages/struktur-organisasi/index.tsx













external_gsap_.gsap.registerPlugin(ScrollTrigger_.ScrollTrigger);

const StrukturOrganisasi = props => {
  const {
    namaKabinet,
    logo,
    strukturOrganisasi,
    pengurus,
    prokers,
    tupoksis
  } = props;

  const groupingData = key => {
    const keyData = pengurus.filter(item => item[key]) // Filter only items with "key" key
    .map(item => item[key]) // Extract "key" objects
    .reduce((acc, curr) => {
      // Group by "nama" and accumulate in an array
      const key = curr.nama;

      if (!acc[key]) {
        acc[key] = [];
      }

      acc[key].push(curr);
      return acc;
    }, {}); // Convert grouped data to an array of objects

    const groupedKeyArray = Object.keys(keyData).map(nama => ({
      nama,
      items: keyData[nama]
    }));
    return groupedKeyArray;
  };

  const groupedByAnggotaJurusan = (pengurus, prokers, tupoksis) => {
    // Create a map to store the prokers grouped by divisi ID
    const prokersByDivisi = {};
    const tupoksisByDivisi = {}; // Group prokers by divisi ID

    prokers.forEach(proker => {
      const divisiId = proker.divisi_pengurus;

      if (!prokersByDivisi[divisiId]) {
        prokersByDivisi[divisiId] = [];
      }

      prokersByDivisi[divisiId].push(proker);
    });
    tupoksis.forEach(tupoksi => {
      const divisiId = tupoksi.divisi_pengurus;

      if (!tupoksisByDivisi[divisiId]) {
        tupoksisByDivisi[divisiId] = [];
      }

      tupoksisByDivisi[divisiId].push(tupoksi);
    }); // Create an object to store the grouped data

    const groupedData = {}; // Iterate through the data and group by "divisi.nama"

    pengurus.forEach(item => {
      if (item.divisi && item.divisi.nama) {
        const divisiName = item.divisi.nama;

        if (!groupedData[divisiName]) {
          // Initialize the group with divisi ID, nama, and prokers
          groupedData[divisiName] = {
            id: item.divisi.id,
            // Add divisi ID
            divisi: divisiName,
            members: [],
            prokers: prokersByDivisi[item.divisi.id] || [],
            // Assign prokers based on divisi ID
            tupoksis: tupoksisByDivisi[item.divisi.id] || [] // Assign prokers based on divisi ID

          };
        } // Extract the desired fields and add to the group


        groupedData[divisiName].members.push({
          id: item.id,
          nama: item.nama,
          jabatan: item.jabatan,
          jurusan: item.jurusan,
          angkatan: item.angkatan,
          linkedin: item.linkedin,
          fotoUrl: item.foto.url,
          instagram: '',
          divisi: {
            id: '',
            nama: ''
          },
          foto: {
            height: 0,
            width: 0,
            url: '',
            formats: {
              thumbnail: {
                url: ''
              }
            }
          }
        });
      }
    }); // Convert the grouped data to an array

    const groupedArray = Object.values(groupedData);
    return groupedArray;
  };

  const {
    0: data
  } = (0,external_react_.useState)({
    namaKabinet: namaKabinet,
    logo: logo,
    strukturOrganisasi: strukturOrganisasi,
    pengurus: groupedByAnggotaJurusan(pengurus, prokers, tupoksis),
    divisi: groupingData('divisi')
  });
  const dispatch = (0,external_react_redux_.useDispatch)();
  const refStruktur = (0,external_react_.useRef)(null);
  const refImage = (0,external_react_.useRef)(null);

  const tabClicked = () => {
    external_gsap_.gsap.fromTo(refImage.current, {
      autoAlpha: 0,
      y: 200,
      scale: .5
    }, {
      autoAlpha: 1,
      y: 0,
      scale: 1,
      ease: 'power3.out',
      animationDuration: 1
    });
  };

  (0,external_react_.useEffect)(() => {
    dispatch((0,pageVisitSlices/* setStatePageVisit */.uK)({
      page: 'Struktur Organisasi'
    }));
    const animation = {
      strukturOrganisasi: external_gsap_.gsap.fromTo(refStruktur.current, {
        autoAlpha: 0,
        y: 200,
        scale: .5
      }, {
        autoAlpha: 1,
        y: 0,
        scale: 1,
        ease: 'power3.out',
        animationDuration: 1
      })
    };
    ScrollTrigger_.ScrollTrigger.create({
      animation: animation.strukturOrganisasi,
      trigger: refStruktur.current,
      start: 'top-=300px center',
      end: 'bottom center',
      markers: false
    });
  }, [dispatch]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: "mt-[13vh] py-3",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
      className: "w-full h-fit",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "px-10 flex flex-col items-center justify-center md:flex-row md:justify-between w-full h-fit gap-5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "hidden md:block md:relative w-[8rem] h-[8rem] md:top-10  animate-spin-cust ",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/vector/vector.svg",
            width: 200,
            height: 200,
            alt: "Kabinet Aerial"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "text-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "text-2xl lg:text-3xl font-bold submenu w-fit",
            children: "Struktur Organisasi"
          }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
            className: "text-lg lg:text-2xl tracking-wide font-black text-outline",
            children: data.namaKabinet
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex justify-center h-[20vh] w- sm:h-[30vh] md:h-[7rem] md:relative md:top-10 lg:right-10",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: `${constants/* API_URL */.T5}${data.logo}`,
            width: 150,
            height: 150,
            alt: "Kabinet Aerial"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        ref: refStruktur,
        className: "relative flex justify-start lg:justify-center items-start flex-wrap px-3 md:px-7 w-full h-fit border-box ",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: `${constants/* API_URL */.T5}${data.strukturOrganisasi}`,
          width: 1000,
          height: 500,
          alt: "Struktur Organisasi"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "absolute z-100 -bottom-20 lg:left-3",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: '/vector/infinity.png',
            width: 150,
            height: 150,
            alt: "infinity"
          })
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
      className: "flex flex-col gap-5 px-3 sm:px-10",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-1",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
          className: "text-lg leading-none sm:text-xl md:text-2xl lg:text-3xl font-bold submenu w-fit pr-2 border-r-2 border-tangerine h-fit",
          children: "Fungsionaris"
        }), /*#__PURE__*/jsx_runtime_.jsx("h6", {
          className: "text-xs sm:text-sm md:text-base md:leading-3 lg:text-2xl font-black text-outline",
          children: "BEM FASILKOM 2023"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-full h-fit overflow-hidden",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_tabs_namespaceObject.Tabs, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.TabList, {
            children: data.pengurus.map((p, i) => {
              return /*#__PURE__*/jsx_runtime_.jsx(external_react_tabs_namespaceObject.Tab, {
                onClick: () => setTimeout(() => tabClicked(), 10),
                children: p.divisi
              }, i);
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex flex-col items-center bg-[#EFEFEF] w-full h-fit px-3 py-10 pb-[7rem]",
            children: data.pengurus.map((p, i) => {
              return /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_tabs_namespaceObject.TabPanel, {
                children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
                  className: "text-2xl text-center font-bold text-typedBlue mb-10",
                  children: p.divisi
                }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                  ref: refImage,
                  className: "flex flex-col min-[550px]:flex-row min-[730px]:flex-row lg:h-[10%] lg:flex-row gap-4 w-full justify-center items-center",
                  children: p.members.map(m => {
                    return /*#__PURE__*/jsx_runtime_.jsx(cardAnggota, {
                      nama: m.nama,
                      angkatan: m.angkatan,
                      jabatan: m.jabatan.nama,
                      jurusan: m.jurusan.nama,
                      foto: m.fotoUrl,
                      linkedin: m.linkedin
                    }, m.id);
                  })
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "w-full h-fit flex flex-col lg:mt-10 lg:flex-row",
                  children: [p.tupoksis.length ? /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "flex flex-col w-full h-fit items-center justify-center mt-10",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "w-full h-fit flex flex-col items-center gap-7",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                        className: "text-2xl text-typedBlue font-bold",
                        children: "Tupoksi"
                      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "px-5",
                        children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
                          className: "list-disc",
                          children: p.tupoksis.map((t, i) => /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "lg:text-sm",
                            children: t.Tupoksi
                          }, i))
                        })
                      })]
                    })
                  }) : null, p.prokers.length ? /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "flex flex-col w-full h-fit items-center justify-center mt-10",
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "w-full h-fit flex flex-col items-center gap-7",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                        className: "text-2xl text-typedBlue font-bold",
                        children: "Proker"
                      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "h-fit w-full flex justify-around gap-3 flex-wrap box-border",
                        children: prokers.map(prok => {
                          if (prok.divisi_pengurus === p.id) {
                            return /*#__PURE__*/jsx_runtime_.jsx(Proker, {
                              prokerName: prok.nama
                            }, prok.id);
                          } else {
                            return null;
                          }
                        })
                      })]
                    })
                  }) : null]
                })]
              }, i);
            })
          })]
        })
      })]
    })]
  });
};

const getServerSideProps = async () => {
  const namaKabinet = await (await fetch(`${constants/* API_URL */.T5}/nama-kabinet`)).json();
  const logo = await (await fetch(`${constants/* API_URL */.T5}/logo`)).json();
  const strukturOrganisasi = await (await fetch(`${constants/* API_URL */.T5}/bagan`)).json();
  const pengurus = await (await fetch(`${constants/* API_URL */.T5}/penguruses`)).json();
  const prokers = await (await fetch(`${constants/* API_URL */.T5}/kategori-penguruses`)).json();
  return {
    props: {
      namaKabinet: namaKabinet.nama,
      logo: logo.logo.url,
      strukturOrganisasi: strukturOrganisasi.bagan.url,
      pengurus: pengurus,
      prokers: prokers.filter(p => p.prokers.length).map(m => m.prokers)[0],
      tupoksis: prokers.filter(t => t.tupoksis.length).map(m => m.tupoksis)[0]
    }
  };
};
/* harmony default export */ const struktur_organisasi = (StrukturOrganisasi);

/***/ }),

/***/ 761:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uK": () => (/* binding */ setStatePageVisit),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export pageVisitSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const pageVisitSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'pageVisit',
  initialState: {
    value: ''
  },
  reducers: {
    setStatePageVisit: (state, {
      payload
    }) => {
      state.value = payload.page;
    }
  }
});
const {
  setStatePageVisit
} = pageVisitSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (pageVisitSlice.reducer);

/***/ }),

/***/ 6139:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 9015:
/***/ ((module) => {

module.exports = require("gsap");

/***/ }),

/***/ 1498:
/***/ ((module) => {

module.exports = require("gsap/dist/ScrollTrigger");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,675], () => (__webpack_exec__(2420)));
module.exports = __webpack_exports__;

})();