"use strict";
(() => {
var exports = {};
exports.id = 639;
exports.ids = [639];
exports.modules = {

/***/ 7687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T5": () => (/* binding */ API_URL),
/* harmony export */   "Yi": () => (/* binding */ EMAIL_BEM)
/* harmony export */ });
/* unused harmony export SELF_URL */
// export const API_URL = "https://web-bem-testing.herokuapp.com";
// export const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_URL = "http://localhost:1337"; // export const SELF_URL = "https://website-bem.vercel.app";

const SELF_URL = process.env.SELF_URL;
const EMAIL_BEM = "bem.fasilkom@upnjatim.ac.id";

/***/ }),

/***/ 190:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ tentang_kami),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./store/pageVisitSlices.ts
var pageVisitSlices = __webpack_require__(761);
// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(9015);
// EXTERNAL MODULE: external "gsap/dist/ScrollTrigger"
var ScrollTrigger_ = __webpack_require__(1498);
;// CONCATENATED MODULE: ./components/visi-misi/index.tsx
"use client";









external_gsap_.gsap.registerPlugin(ScrollTrigger_.ScrollTrigger);
function Index(props) {
  const dispatch = (0,external_react_redux_.useDispatch)();
  dispatch((0,pageVisitSlices/* setStatePageVisit */.uK)({
    page: 'Visi-Misi'
  }));
  const visiSectionRef = (0,external_react_.useRef)(null);
  const misiSectionRef = (0,external_react_.useRef)(null);
  (0,external_react_.useEffect)(() => {
    const animation = {
      visi: external_gsap_.gsap.fromTo(visiSectionRef.current, {
        autoAlpha: 0,
        x: -100
      }, {
        autoAlpha: 1,
        x: 0
      }),
      misi: external_gsap_.gsap.fromTo(misiSectionRef.current, {
        autoAlpha: 0,
        x: 100
      }, {
        autoAlpha: 1,
        x: 0
      })
    };
    ScrollTrigger_.ScrollTrigger.create({
      animation: animation.visi,
      trigger: visiSectionRef.current,
      start: 'top-=200px center',
      end: '400px 40%',
      markers: false,
      onLeave: () => animation.visi.reverse(),
      onLeaveBack: () => animation.visi.reverse(),
      onEnterBack: () => animation.visi.play()
    });
    ScrollTrigger_.ScrollTrigger.create({
      animation: animation.misi,
      trigger: misiSectionRef.current,
      start: 'top-=200px center',
      end: '400px 40%',
      markers: false,
      onLeave: () => animation.misi.reverse(),
      onLeaveBack: () => animation.misi.reverse(),
      onEnterBack: () => animation.misi.play()
    });
  }, []);
  const {
    visi,
    misi
  } = props;
  console.log(misi);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: "flex flex-col justify-center gap-10 lg:gap-16 h-fit md:px-8 lg:h-[100vh] lg:w-full box-border",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
      ref: visiSectionRef,
      className: "flex flex-col md:flex-row items-center gap-10",
      children: [/*#__PURE__*/jsx_runtime_.jsx("figure", {
        className: "sm:flex sm:justify-center md:w-[25%] md:h-fit ",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/icons/visi.png",
          width: 150,
          height: 150,
          alt: "Visi"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "flex flex-col flex-wrap gap-5 md:w-[75%]",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          className: "font-bold text-2xl text-center md:text-start text-typedBlue tracking-wider",
          children: "Visi"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-justify lg:tracking-wide lg:leading-7",
          children: visi
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
      ref: misiSectionRef,
      className: "flex flex-col md:flex-row-reverse  items-center gap-10",
      children: [/*#__PURE__*/jsx_runtime_.jsx("figure", {
        className: "sm:flex sm:justify-center md:w-[25%] md:h-fit",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/icons/misi.png",
          width: 150,
          height: 150,
          alt: "Visi"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "flex flex-col flex-wrap gap-5 md:w-[75%]",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          className: "font-bold text-2xl text-center md:text-end text-typedBlue tracking-wider",
          children: "Misi"
        }), misi.map((m, i) => {
          return /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-justify lg:tracking-wide lg:leading-7",
            children: m.deskripsi
          }, i);
        })]
      })]
    })]
  });
}
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(7687);
;// CONCATENATED MODULE: ./components/FilosofiLogo/index.tsx






external_gsap_.gsap.registerPlugin(ScrollTrigger_.ScrollTrigger);

function FilosofiLogo_Index(props) {
  const sectionRef = (0,external_react_.useRef)(null);
  (0,external_react_.useEffect)(() => {
    const sectionAnimation = external_gsap_.gsap.fromTo(sectionRef.current, {
      autoAlpha: 0,
      y: 200,
      scale: .6,
      animationDuration: 2
    }, {
      autoAlpha: 1,
      y: 0,
      ease: 'bounce.out',
      scale: 1,
      animationDuration: 2
    });
    ScrollTrigger_.ScrollTrigger.create({
      animation: sectionAnimation,
      trigger: sectionRef.current,
      start: 'top-=500 center',
      end: 'bottom center',
      markers: false,
      onLeaveBack: () => sectionAnimation.reverse()
    });
  }, []);
  const {
    url
  } = props;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    ref: sectionRef,
    className: "mt-[13vh] flex flex-col gap-10 h-fit w-full box-border ",
    children: [/*#__PURE__*/jsx_runtime_.jsx("section", {
      className: "w-full text-center",
      children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: "m-auto font-bold text-typedBlue text-3xl submenu w-fit after:-bottom-2 after:right-[calc(100%/5)] after:w-[115px]",
        children: "Filosofi Logo"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("section", {
      className: "w-full flex justify-center items-center box-border",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: `${constants/* API_URL */.T5}${url}`,
        width: 800,
        height: 800,
        alt: "Filosofi Logo",
        quality: 100
      })
    })]
  });
}
;// CONCATENATED MODULE: ./components/About/tentang-kami/index.tsx





function index(props) {
  const {
    namaKabinet,
    content,
    logo
  } = props;
  console.log(namaKabinet);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: "h-fit lg:h-screen box-border flex flex-col lg:gap-20 pl-0 lg:pl-[2.5rem] mt-[13vh] ",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "m-auto w-fit text-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: "text-2xl lg:text-3xl font-bold submenu w-fit",
        children: "Tentang Kami"
      }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
        className: "text-lg lg:text-2xl tracking-wide font-black text-outline",
        children: namaKabinet
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "absolute w-[8rem] h-[8rem] left-4 sm:left-14 lg:left-20 top-20 lg:top-10  animate-spin-cust ",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/vector/vector.svg",
        width: 200,
        height: 200,
        alt: "Kabinet Aerial"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col-reverse gap-[2rem] lg:gap-0 lg:flex-row",
      children: [/*#__PURE__*/jsx_runtime_.jsx("article", {
        className: " flex flex-col justify-center lg:justify-around pb-14 w-full lg:w-[60%] lg:pt-20 box-border",
        children: /*#__PURE__*/jsx_runtime_.jsx("article", {
          className: "flex flex-wrap",
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-sm text-justify leading-5",
            children: content
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("aside", {
        className: " relative mt-[8rem] lg:mt-0 flex flex-col gap-[3rem]  w-full h-fit lg:h- lg:w-[40%]",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-[15rem] h-[15rem] sm:w-[20rem] sm:h-[20rem] m-auto lg:w-[22rem] lg:h-[22rem] lg:relative flex justify-center",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: `${constants/* API_URL */.T5}${logo}`,
            width: 300,
            height: 600,
            alt: "Kabinet Aerial"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full flex flex-col items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "text-lg font-bold submenu w-fit",
            children: "BEM FASILKOM UPNVJT"
          }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
            className: "text-lg tracking-wide font-black text-outline",
            children: namaKabinet
          })]
        })]
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./pages/tentang-kami/index.tsx










const TentangKami = props => {
  const dispatch = (0,external_react_redux_.useDispatch)();
  (0,external_react_.useEffect)(() => {
    dispatch((0,pageVisitSlices/* setStatePageVisit */.uK)({
      page: 'tentang-kami'
    }));
  }, [dispatch]);
  const {
    namaKabinet,
    logo,
    aboutContent,
    visi,
    misi,
    filosofiLogo
  } = props;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: "px-10 relative",
    children: [/*#__PURE__*/jsx_runtime_.jsx(index, {
      namaKabinet: namaKabinet,
      logo: logo,
      content: aboutContent
    }), /*#__PURE__*/jsx_runtime_.jsx(Index, {
      visi: visi,
      misi: misi
    }), /*#__PURE__*/jsx_runtime_.jsx(FilosofiLogo_Index, {
      url: filosofiLogo
    })]
  });
};

const getServerSideProps = async () => {
  const namaKabinet = await (await fetch(`${constants/* API_URL */.T5}/nama-kabinet`)).json();
  const logo = await (await fetch(`${constants/* API_URL */.T5}/logo`)).json();
  const aboutContent = await (await fetch(`${constants/* API_URL */.T5}/about-content`)).json();
  const visi = await (await fetch(`${constants/* API_URL */.T5}/visi`)).json();
  const misi = await (await fetch(`${constants/* API_URL */.T5}/misis`)).json();
  const filosofiLogo = await (await fetch(`${constants/* API_URL */.T5}/filosofi-logo`)).json();
  return {
    props: {
      namaKabinet: namaKabinet.nama,
      logo: logo.logo.url,
      aboutContent: aboutContent.content,
      visi: visi.teks,
      misi: misi,
      filosofiLogo: filosofiLogo.url.formats.medium.url
    }
  };
};
/* harmony default export */ const tentang_kami = (TentangKami);

/***/ }),

/***/ 761:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uK": () => (/* binding */ setStatePageVisit),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export pageVisitSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const pageVisitSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'pageVisit',
  initialState: {
    value: ''
  },
  reducers: {
    setStatePageVisit: (state, {
      payload
    }) => {
      state.value = payload.page;
    }
  }
});
const {
  setStatePageVisit
} = pageVisitSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (pageVisitSlice.reducer);

/***/ }),

/***/ 6139:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 9015:
/***/ ((module) => {

module.exports = require("gsap");

/***/ }),

/***/ 1498:
/***/ ((module) => {

module.exports = require("gsap/dist/ScrollTrigger");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,675], () => (__webpack_exec__(190)));
module.exports = __webpack_exports__;

})();