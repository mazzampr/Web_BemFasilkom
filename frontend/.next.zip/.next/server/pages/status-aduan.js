(() => {
var exports = {};
exports.id = 629;
exports.ids = [629];
exports.modules = {

/***/ 3175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ DocumentHead)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);



const DocumentHead = ({
  pageTitle
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
      rel: "shortcut icon",
      href: "/bem-fasilkom-logo.png",
      type: "image/x-icon"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
      children: [pageTitle ? `${pageTitle} | ` : null, " ", 'BEM FASILKOM UPN "Veteran" Jawa Timur']
    })]
  });
};

/***/ }),

/***/ 7687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T5": () => (/* binding */ API_URL),
/* harmony export */   "Yi": () => (/* binding */ EMAIL_BEM)
/* harmony export */ });
/* unused harmony export SELF_URL */
// export const API_URL = "https://web-bem-testing.herokuapp.com";
// export const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_URL = "http://localhost:1337"; // export const SELF_URL = "https://website-bem.vercel.app";

const SELF_URL = process.env.SELF_URL;
const EMAIL_BEM = "bem.fasilkom@upnjatim.ac.id";

/***/ }),

/***/ 457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ status_aduan),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./styles/StatusAduan.module.scss
var StatusAduan_module = __webpack_require__(602);
var StatusAduan_module_default = /*#__PURE__*/__webpack_require__.n(StatusAduan_module);
// EXTERNAL MODULE: external "next-auth/client"
var client_ = __webpack_require__(8104);
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(7687);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(3879);
// EXTERNAL MODULE: ./components/DocumentHead.tsx
var DocumentHead = __webpack_require__(3175);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./store/pageVisitSlices.ts
var pageVisitSlices = __webpack_require__(761);
;// CONCATENATED MODULE: ./pages/status-aduan.tsx













const StatusAduanPage = props => {
  const dispatch = (0,external_react_redux_.useDispatch)();
  dispatch((0,pageVisitSlices/* setStatePageVisit */.uK)({
    page: 'status-aduan'
  }));
  const {
    columns,
    session
  } = props;
  console.log(session);
  const router = (0,router_namespaceObject.useRouter)();
  const {
    0: status,
    1: setStatus
  } = (0,external_react_.useState)(0);
  (0,external_react_.useEffect)(() => {
    if (!session) {
      router.push('/aduan-dan-aspirasi');
    }
  }, []);
  const initialLanesOffset = {};
  columns.lanes.forEach(lane => {
    initialLanesOffset[lane.id] = lane.cards.length;
  });
  const offsets = (0,external_react_.useRef)(initialLanesOffset);
  const shouldFetchNewData = (0,external_react_.useRef)(true);
  const {
    0: listAduan,
    1: updateListAduan
  } = (0,external_react_.useReducer)(listAduanReducer, columns);

  function listAduanReducer(prevState, payload) {
    if (payload.newAduans.length === 0) {
      shouldFetchNewData.current = false;
      return prevState;
    }

    const prevStateClone = JSON.parse(JSON.stringify(prevState));
    const currentLaneIdx = prevStateClone.lanes.findIndex(lane => {
      return lane.id === payload.laneId;
    });
    if (currentLaneIdx === -1) return prevState;
    payload.newAduans.forEach(newAduan => {
      prevStateClone.lanes[currentLaneIdx].cards.push(newAduan);
    });
    const currentOffsets = offsets.current;
    currentOffsets[payload.laneId] = currentOffsets[payload.laneId] + 5;
    offsets.current = currentOffsets;
    return prevStateClone;
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(DocumentHead/* DocumentHead */.j, {
      pageTitle: "Status Aduan"
    }), !session ? null : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (StatusAduan_module_default()).container,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
        className: (StatusAduan_module_default()).title,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: (StatusAduan_module_default()).title_main,
          children: "Status Aduan"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: (StatusAduan_module_default()).title_sub,
          children: ["Lihat status aduan dan aspirasi ", /*#__PURE__*/jsx_runtime_.jsx("br", {
            className: (StatusAduan_module_default()).enter
          }), "KM FASILKOM di bawah ini"]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (StatusAduan_module_default()).kanban_wrapper
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "min-w-[360px] ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-full h-fit border-b-2 shadow shadow-gray-400 border-[#FEAB6C]",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
            className: "w-full h-full text-center  flex text-[12px] justify-around  py-2",
            children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
              className: `text-[#094379] w-[calc(100%/3)]  text-[1.3em] sm:text-[1.5em] md:text-[1.6em]  hover:font-bold cursor-pointer`,
              onClick: () => setStatus(0),
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: ` ${status === 0 ? 'font-bold  text-[#FEAB6C]' : null}`,
                children: "Belum Dikerjakan"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              className: "text-[#094379] w-[calc(100%/3)]  hover:text-[#FEAB6C] text-[1.3em] sm:text-[1.5em] md:text-[1.6em] active:font-bold hover:font-bold cursor-pointer",
              onClick: () => setStatus(1),
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: ` ${status === 1 ? 'font-bold  text-[#FEAB6C]' : null}`,
                children: "Dalam Pengerjaan"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              className: "text-[#094379] w-[calc(100%/3)]  hover:text-[#FEAB6C] text-[1.3em] sm:text-[1.5em] md:text-[1.6em] active:font-bold hover:font-bold cursor-pointer",
              onClick: () => setStatus(2),
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: ` ${status === 2 ? 'font-bold  text-[#FEAB6C]' : null}`,
                children: "Selesai"
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-full h-[555px] pt-10 pb-5 overflow-y-scroll lg:grid lg:grid-cols-3 lg:grid-rows-auto",
          children: columns.lanes[status].cards.map(aduan => {
            return /*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
              className: "w-[90%] mb-5 lg:mb-0 border-2 border-[#FEAB6C] h-fit p-2 rounded-[10px] mx-auto hover:bg-[#FEAB6C] hover:border-none transition-all hover:bg-opacity-[25%] ",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "text-[#094379] font-semibold text-[19px] sm:text-[24px] lg:text-[24px]",
                children: `${aduan.title}`
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "text-[15px] sm:text-[19px] text-gray-500",
                children: aduan.description
              })]
            }, aduan.id);
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: () => (0,client_.signOut)({
            callbackUrl: `/aduan-dan-aspirasi`
          }),
          className: "h-fit w-fit rounded-full border border-slate-200 text-white bg-red-600 p-2 px-5 shadow shadow-gray-500 hover:bg-white hover:border-red-600 hover:border-2 hover:font-bold hover:scale-[1.02] hover:text-red-600  mx-auto block ",
          children: "Log-Out"
        })]
      })]
    })]
  });
};

const getServerSideProps = async context => {
  const session = await (0,client_.getSession)(context);
  console.log('session = ', session);
  let listStatusAduan = await (await fetch(`${constants/* API_URL */.T5}/status-aduans`)).json();
  listStatusAduan.sort((statusAduan1, statusAduan2) => statusAduan1.urutan - statusAduan2.urutan);
  const columns = {
    lanes: await Promise.all(listStatusAduan.map(async statusAduan => {
      const cards = await (await fetch(`${constants/* API_URL */.T5}/aspirasi-dan-aduans?_sort=created_at:DESC&_start=0&_limit=7&status_aduan_eq=${statusAduan.id}`)).json();
      return {
        id: statusAduan.id,
        title: statusAduan.status,
        cards: cards.map(aduan => {
          return {
            id: aduan.id,
            title: `${aduan.tipe} dari ${aduan.nama}`,
            description: external_date_fns_.format(new Date(aduan.created_at), "d MMMM yyyy - HH:mm")
          };
        })
      };
    }))
  };
  return {
    props: {
      columns,
      listStatusAduan,
      session
    }
  };
};
/* harmony default export */ const status_aduan = (StatusAduanPage);

/***/ }),

/***/ 761:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uK": () => (/* binding */ setStatePageVisit),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export pageVisitSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6139);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const pageVisitSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'pageVisit',
  initialState: {
    value: ''
  },
  reducers: {
    setStatePageVisit: (state, {
      payload
    }) => {
      state.value = payload.page;
    }
  }
});
const {
  setStatePageVisit
} = pageVisitSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (pageVisitSlice.reducer);

/***/ }),

/***/ 602:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "StatusAduan_container__1UO5Q",
	"title": "StatusAduan_title__1szm4",
	"title_main": "StatusAduan_title_main__2sPZ9",
	"kanban_wrapper": "StatusAduan_kanban_wrapper__1X8OP"
};


/***/ }),

/***/ 6139:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3879:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 8104:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/client");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(457));
module.exports = __webpack_exports__;

})();