(() => {
var exports = {};
exports.id = 505;
exports.ids = [505];
exports.modules = {

/***/ 7036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7149);
/* harmony import */ var _styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7687);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var _hooks_useDarkNavLinks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2698);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3879);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_DocumentHead__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3175);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_pageVisitSlices__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(761);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9015);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(gsap__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1498);
/* harmony import */ var gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_10__);














gsap__WEBPACK_IMPORTED_MODULE_9__.gsap.registerPlugin(gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_10__.ScrollTrigger);

const Berita = props => {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
  const refSection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  const {
    listBerita,
    beritaCount
  } = props;
  const paginationStart = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(listBerita.length);
  const {
    0: beritaList,
    1: setBeritaList
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(listBerita);
  const {
    0: isFetchingNewData,
    1: setIsFetchingNewData
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  (0,_hooks_useDarkNavLinks__WEBPACK_IMPORTED_MODULE_4__/* .useDarkNavLinks */ .t)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    dispatch((0,_store_pageVisitSlices__WEBPACK_IMPORTED_MODULE_8__/* .setStatePageVisit */ .uK)({
      page: 'Berita'
    }));
    const animation = gsap__WEBPACK_IMPORTED_MODULE_9__.gsap.fromTo(refSection.current, {
      autoAlpha: 0,
      y: 400
    }, {
      autoAlpha: 1,
      duration: 1,
      y: 0,
      ease: 'power3.out',
      animationDuration: 1
    });
    gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_10__.ScrollTrigger.create({
      animation: animation,
      trigger: refSection.current,
      start: 'top-=500px center',
      end: 'bottom center'
    });
  }, [dispatch]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DocumentHead__WEBPACK_IMPORTED_MODULE_6__/* .DocumentHead */ .j, {
      pageTitle: "Fasilkom News"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().container),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().textberita),
        children: "Fasilkom News"
      }), beritaList.length > 0 ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          ref: refSection,
          className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().berita_list_container),
          children: beritaList.map((berita, idx) => {
            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__.default, {
              href: `/berita/${berita.id}`,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().news_card),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                  className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().news_thumbnail),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: berita.cover ? _constants__WEBPACK_IMPORTED_MODULE_2__/* .API_URL */ .T5 + berita.cover.url : 'placeholder_image_url',
                    alt: "berita"
                  })
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                  className: "flex w-full h-fit justify-between items-center font-light",
                  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().news_date),
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                      className: "inline w-[24px] h-[24px] mr-1 m-auto",
                      width: 24,
                      height: 24,
                      alt: "date",
                      src: "icons/date.svg"
                    }), date_fns__WEBPACK_IMPORTED_MODULE_5__.format(new Date(berita.created_at), "d MMMM yyyy")]
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "text-[12px]",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                      className: "inline w-[24px] h-[24px] mr-1",
                      width: 24,
                      height: 24,
                      alt: "date",
                      src: "icons/user.svg"
                    }), berita.author.firstname]
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                  className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().news_title),
                  children: berita.judul
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                  className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().news_desc),
                  children: berita.pratinjau.length > 200 ? berita.pratinjau.slice(0, 200) + "..." : berita.pratinjau
                })]
              })
            }, idx);
          })
        }), beritaList.length < beritaCount ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
          className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().news_load_more),
          disabled: isFetchingNewData,
          onClick: () => {
            setIsFetchingNewData(true);
            fetch(`${_constants__WEBPACK_IMPORTED_MODULE_2__/* .API_URL */ .T5}/beritas?_sort=created_at:DESC&_start=${paginationStart.current}&_limit=3`).then(res => {
              if (!res.ok) {
                throw new Error('Network response was not ok');
              }

              return res.json();
            }).then(newNews => {
              setBeritaList([...beritaList, ...newNews]);
              console.log('aaaaaa');
              console.log(beritaList);
              console.log([...beritaList, ...newNews]);
              setIsFetchingNewData(false);
            }).catch(error => {
              console.error('Error fetching data:', error);
              setIsFetchingNewData(false);
            });
          },
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            className: "border border-black",
            children: [isFetchingNewData ? "Mengambil data" : "Lihat lebih banyak", ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
              className: "inline ml-1 mb-1 rotate-[90deg]",
              width: 20,
              height: 20,
              src: "icons/arrowRight.svg",
              alt: "arrow"
            })]
          })
        }) : null]
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_SemuaBerita_module_scss__WEBPACK_IMPORTED_MODULE_11___default().no_news_notice),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
          children: "Ups, belum ada berita di sini"
        })
      })]
    })]
  });
};

const getServerSideProps = async () => {
  const [beritaList, beritaCount] = await Promise.all([await (await fetch(`${_constants__WEBPACK_IMPORTED_MODULE_2__/* .API_URL */ .T5}/beritas?_sort=created_at:DESC&_start=0&_limit=6`)).json(), await (await fetch(`${_constants__WEBPACK_IMPORTED_MODULE_2__/* .API_URL */ .T5}/beritas/count`)).json()]);
  return {
    props: {
      listBerita: beritaList,
      beritaCount
    }
  };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Berita);

/***/ }),

/***/ 7149:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "SemuaBerita_container__1dVRN",
	"textberita": "SemuaBerita_textberita__R3lg8",
	"berita_list_container": "SemuaBerita_berita_list_container__3mLNn",
	"no_news_notice": "SemuaBerita_no_news_notice__1BMqY",
	"news_card": "SemuaBerita_news_card__23wrz",
	"news_thumbnail": "SemuaBerita_news_thumbnail__8RN46",
	"news_title": "SemuaBerita_news_title__1RmXa",
	"news_date": "SemuaBerita_news_date__vFciv",
	"news_desc": "SemuaBerita_news_desc__f_AiM",
	"news_box": "SemuaBerita_news_box__1f_Mi",
	"news_box_image": "SemuaBerita_news_box_image__210I-",
	"news_box_title": "SemuaBerita_news_box_title__2Gy7N",
	"p_title": "SemuaBerita_p_title__3t6u0",
	"p_thumbnail": "SemuaBerita_p_thumbnail__3gJKn",
	"p_news_info": "SemuaBerita_p_news_info__1xaE9",
	"news_load_more": "SemuaBerita_news_load_more__2a4Sx",
	"upDown": "SemuaBerita_upDown__Es6_B"
};


/***/ }),

/***/ 6139:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3879:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 9015:
/***/ ((module) => {

"use strict";
module.exports = require("gsap");

/***/ }),

/***/ 1498:
/***/ ((module) => {

"use strict";
module.exports = require("gsap/dist/ScrollTrigger");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,991,196], () => (__webpack_exec__(7036)));
module.exports = __webpack_exports__;

})();