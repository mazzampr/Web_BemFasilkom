(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ NavbarBackgroundContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const NavbarBackgroundContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
  navbarBackgroundColor: "#fff",
  setNavbarBackgroundColor: () => {}
});

/***/ }),

/***/ 2313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(6139);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/Navbar/styles.module.scss
var styles_module = __webpack_require__(7930);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
// EXTERNAL MODULE: ./components/Assets/ButtonOutline.tsx
var ButtonOutline = __webpack_require__(4717);
;// CONCATENATED MODULE: external "react-headroom"
const external_react_headroom_namespaceObject = require("react-headroom");
var external_react_headroom_default = /*#__PURE__*/__webpack_require__.n(external_react_headroom_namespaceObject);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
;// CONCATENATED MODULE: ./store/hamburgerSlices.ts

const navbarSlice = (0,toolkit_.createSlice)({
  name: 'hamburgerMode',
  initialState: {
    value: false
  },
  reducers: {
    setStateNavbar: (state, {
      payload
    }) => {
      state.value = payload === 'Homepage' ? state.value : !state.value;
    }
  }
});
const {
  setStateNavbar
} = navbarSlice.actions;
/* harmony default export */ const hamburgerSlices = (navbarSlice.reducer);
;// CONCATENATED MODULE: ./components/Assets/Hamburger.tsx





function Hamburger() {
  const navbarShow = (0,external_react_redux_.useSelector)(state => state.navbarSlice.value);
  const dispatch = (0,external_react_redux_.useDispatch)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    onClick: () => dispatch(setStateNavbar('')),
    className: `relative box-border rounded-md hover:bg-slate-400 cursor-pointer ${!navbarShow ? 'bg-[rgb(148 163 184)]' : 'bg-transparent'}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
      className: "cursor-pointer absolute  w-full h-full opacity-0 pointer-events-auto",
      type: "checkbox"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "cursor-pointer flex w-fit h-full  lg:hidden rounded-md p-1",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-full",
        children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
          "aria-hidden": "true",
          focusable: "false",
          "data-prefix": "fas",
          "data-icon": "bars",
          className: ` ${!navbarShow ? 'flex' : 'hidden'} svg-inline--fa fa-bars h-6 w-6`,
          role: "img",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 448 512",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            fill: "currentColor",
            d: "M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
          "aria-hidden": "true",
          focusable: "false",
          "data-prefix": "fas",
          "data-icon": "xmark",
          className: `${!navbarShow ? 'hidden' : 'flex'} svg-inline--fa fa-xmark h-6 w-6`,
          role: "img",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 384 512",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            fill: "currentColor",
            d: "M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"
          })
        })]
      })
    })]
  });
}
;// CONCATENATED MODULE: ./store/linkDetectSlices.ts

const linkClickedSlice = (0,toolkit_.createSlice)({
  name: 'linkMode',
  initialState: {
    value: ''
  },
  reducers: {
    setStateLink: (state, {
      payload
    }) => {
      state.value = payload.link;
    }
  }
});
const {
  setStateLink
} = linkClickedSlice.actions;
/* harmony default export */ const linkDetectSlices = (linkClickedSlice.reducer);
;// CONCATENATED MODULE: ./components/Navbar/index.tsx














;
const setStateNavbarFalse = (0,toolkit_.createAction)('navbar/setStateNavbarFalse');
const navLinks = [{
  text: "Profile",
  links: [{
    text: "Struktur Organisasi",
    link: "/struktur-organisasi"
  }, {
    text: 'Tentang Kami',
    link: '/tentang-kami'
  }]
}, {
  text: "Fasilkom News",
  link: "/berita"
}, {
  text: "Our Services",
  links: [{
    text: 'Aduan dan Aspirasi',
    link: '/aduan-dan-aspirasi'
  }, {
    text: 'Bisnis Mitra',
    link: '/bisnis-mitra'
  }]
}];
const Navbar = () => {
  const dispatch = (0,external_react_redux_.useDispatch)();
  const navbarShow = (0,external_react_redux_.useSelector)(state => state.navbarSlice.value);
  const linkClicked = (0,external_react_redux_.useSelector)(state => state.linkClickedSlice.value);
  const pageVisit = (0,external_react_redux_.useSelector)(state => state.pageVisitSlice.value);
  const {
    0: scrollY,
    1: setScrollY
  } = (0,external_react_.useState)(0);
  const {
    0: logoClicked,
    1: setLogoClicked
  } = (0,external_react_.useState)(false);
  const {
    0: submenuVisible,
    1: setSubmenuVisible
  } = (0,external_react_.useState)(new Array(navLinks.length).fill(false));

  const toggleSubmenu = index => {
    // Toggle the submenu visibility for the specified index
    const updatedSubmenuVisible = [...submenuVisible];
    updatedSubmenuVisible[index] = !updatedSubmenuVisible[index];
    setSubmenuVisible(updatedSubmenuVisible);
  };

  (0,external_react_.useEffect)(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handleClickedNavbar = link => {
    dispatch(setStateNavbar({
      link
    }));
    dispatch(setStateLink({
      link
    }));
  };

  return /*#__PURE__*/jsx_runtime_.jsx((external_react_headroom_default()), {
    className: "fixed z-[99] min-w-[100%]",
    style: {
      transition: 'all 1s ease-in-out'
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
      className: `flex items-center justify-between lg:justify-evenly w-[100vw]  ${scrollY > 0 && pageVisit != 'Bisnis-Mitra' ? 'bg-[#FFD7B7]' : scrollY > 0 && pageVisit === 'Bisnis-Mitra' ? 'bg-orange-500' : 'bg-transparent'} ${pageVisit != 'Bisnis-Mitra' ? 'h-[13vh]' : 'pb-2 pt-2 lg:pt-0 lg:pb-0 lg:h-[17vh] lg:px-12'}`,
      style: {
        transition: 'all 1s ease-in-out'
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx("section", {
        className: "flex w-[60%] lg:w-[20%]",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
            onClick: () => navbarShow ? setLogoClicked(true) : setLogoClicked(false),
            className: "flex items-center ",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: `${pageVisit === 'Bisnis-Mitra' ? '/logo/kabinetAerialWhite.svg' : '/logo/kabinetArial.svg'}`,
              alt: "Logo BEM Fasilkom UPN 'Veteran' Jawa Timur",
              className: (styles_module_default()).logo_navbar,
              width: pageVisit === 'Bisnis-Mitra' ? 60 : 50,
              height: pageVisit === 'Bisnis-Mitra' ? 60 : 40
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "text-left flex flex-col justify-center",
              children: pageVisit === 'Bisnis-Mitra' ? /*#__PURE__*/jsx_runtime_.jsx("h5", {
                className: "text-white font-semibold lg:text-base text-sm tracking-wide",
                children: "Bismit Aerial."
              }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
                  className: " font-semibold text-xs sm:text-sm tracking-wide",
                  children: "BEM FASILKOM 2023"
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: " font-extralight text-xs tracking-wide",
                  children: 'UPN "VETERAN" Jawa Timur'
                })]
              })
            })]
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
        className: `${pageVisit === 'Bisnis-Mitra' ? 'lg:items-center' : null} bg-white lg:bg-transparent lg:justify-evenly text-2xl px-5 lg:px-0 lg:text-base w-screen absolute ${navbarShow ? 'top-[13vh]' : '-top-[130vh]'} duration-500 -ml-2 md:w-full lg:ml-0 lg:static flex flex-col py-10 lg:py-0 gap-10 lg:gap-20 lg:flex-row lg:w-[70%] h-screen z-100 lg:z-0 max-h-screen lg:max-h-none lg:h-fit box-content mx-5`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("section", {
          className: `flex flex-col lg:flex-row justify-around  ${pageVisit === 'Bisnis-Mitra' ? 'lg:px-16 lg:items-center' : null} w-fit max-h-[80%] lg:max-h-none lg:w-[70%] h-[60%] lg:h-fit `,
          children: pageVisit != 'Bisnis-Mitra' ? navLinks.map((menu, i) => menu.links ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
            className: "group relative z-[100] cursor-pointer box-border h-fit",
            onClick: () => toggleSubmenu(i),
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "lg:group-hover:border-b-2 border-b-black flex justify-between w-fit lg:px-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                className: `${linkClicked === menu.text ? 'text-typedBlue font-bold' : 'text-black'}`,
                children: menu.text
              }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                className: "group-hover:rotate-180 transition-transform duration-400",
                src: '/icons/caret.svg',
                width: 10,
                height: 10,
                alt: "Profile"
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
              className: `mt-2 lg:mt-0 ${submenuVisible[i] ? "flex flex-col gap-4 h-fit py-2" : "hidden"} lg:py-0 lg:block lg:absolute group lg:invisible lg:group-hover:visible w-[200px] lg:shadow lg:shadow-slate-400 bg-white  overflow-y-auto  min-h-[fit] max-h-[8rem] rounded-md`,
              children: menu.links.map((subMenu, subIndex) => /*#__PURE__*/jsx_runtime_.jsx("li", {
                className: "lg:invisible lg:group-hover:visible w-full flex flex-col gap-3 lg:gap-0 ",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: subMenu.link,
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    onClick: () => handleClickedNavbar(menu.text),
                    className: `px-[.5rem] py-1 block lg:text-center h-full hover:bg-tangerine hover:text-typedBlue text-base lg:text-sm font-medium `,
                    children: subMenu.text
                  })
                })
              }, `submenu-${subIndex}`))
            })]
          }, `menu-${i}`) : /*#__PURE__*/jsx_runtime_.jsx("section", {
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: menu.link,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => handleClickedNavbar(menu.text),
                className: `${linkClicked === menu.text ? 'text-typedBlue font-bold' : 'text-black'} hover:border-b-2 border-b-black w-fit`,
                children: menu.text
              })
            })
          }, `menu-${i}`)) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: '#service',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => handleClickedNavbar('Service'),
                className: `text-black lg:text-white text-lg hover:text-xl hover:font-bold hover:duration-100 w-fit`,
                children: "Service"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: '#portofolio',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => handleClickedNavbar('Portofolio'),
                className: `text-black lg:text-white text-lg hover:text-xl hover:font-bold hover:duration-100 w-fit`,
                children: "Portofolio"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: '#testimonials',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => handleClickedNavbar('Testimonials'),
                className: `text-black lg:text-white text-lg hover:text-xl hover:font-bold hover:duration-100 w-fit`,
                children: "Testimonials"
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(ButtonOutline/* default */.Z, {
          content: `${pageVisit === 'Bisnis-Mitra' ? 'Contact Us' : 'Event'}`,
          width: '6.3rem',
          bismitMode: pageVisit === 'Bisnis-Mitra' ? true : false
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("section", {
        className: "w-[20%] lg:hidden flex justify-end pr-5 md:pr-8",
        children: /*#__PURE__*/jsx_runtime_.jsx(Hamburger, {})
      })]
    })
  });
};
// EXTERNAL MODULE: ./store/pageVisitSlices.ts
var pageVisitSlices = __webpack_require__(761);
;// CONCATENATED MODULE: ./store/store.ts




/* harmony default export */ const store = ((0,toolkit_.configureStore)({
  reducer: {
    navbarSlice: hamburgerSlices,
    linkClickedSlice: linkDetectSlices,
    pageVisitSlice: pageVisitSlices/* default */.ZP
  }
}));
// EXTERNAL MODULE: external "next-auth/client"
var client_ = __webpack_require__(8104);
// EXTERNAL MODULE: ./contexts/navbar-background.ts
var navbar_background = __webpack_require__(7359);
;// CONCATENATED MODULE: ./components/Footer/index.tsx






const Footer = () => {
  const pageVisit = (0,external_react_redux_.useSelector)(state => state.pageVisitSlice.value);
  return /*#__PURE__*/jsx_runtime_.jsx("footer", {
    className: `w-full ${pageVisit === 'Bisnis-Mitra' ? null : 'lg:px-10 lg:pt-16'}  flex flex-col justify-center bg-peach mt-[13vh]`,
    children: pageVisit === 'Bisnis-Mitra' ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "w-full h-full flex flex-col justify-between border-b-2 border-black bg-footer-bismit bg-cover bg-top",
        children: [/*#__PURE__*/jsx_runtime_.jsx("section", {
          className: " w-full h-[60vh] bg-footer-cover-transparent flex justify-center items-center",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col items-center gap-5",
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "text-white text-[1.2em] text-center",
              children: "Grow Your Business Faster Than Ever Before"
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "#",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "hover:scale-[1.1] duration-300 w-fit bg-white text-sky-500 py-3 px-6 rounded-xl",
                children: "Contact Us"
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("section", {
          className: `h-[10vh] w-full bg-orange-500 flex items-center justify-center`,
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-white text-[.7em] sm:text-[.9em] text-center",
            children: "Copyright \xA9 2023, Bidang Penelitian dan Pengembangan BEM Fasillkom UPNVJT"
          })
        })]
      })
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: "w-full h-full pt-10 lg:pb-4 lg:pt-0 flex flex-col lg:flex-row justify-between border-b-2 border-black",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
          className: "w-full lg:w-[26%] flex flex-col items-center justify-center gap-8 mb-8 ",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: '/logo/kabinetArial.svg',
              width: 100,
              height: 100,
              alt: "KabinetAerial"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-col gap-3",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-3",
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  src: '/logo/UPN.svg',
                  width: 40,
                  height: 40,
                  alt: 'UPN "Veteran" Jawa Timur '
                }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  src: '/logo/BEM_FASILKOM.svg',
                  width: 40,
                  height: 40,
                  alt: 'UPN "Veteran" Jawa Timur '
                }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  src: '/logo/KM.svg',
                  width: 40,
                  height: 40,
                  alt: 'UPN "Veteran" Jawa Timur '
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "font-semibold",
                  children: "BEM FASILKOM 2023"
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: 'UPN "VETERAN" Jawa Timur'
                })]
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "lg:mr-14 font-bold tracking-wide",
            children: '"Satu Fasilkom, Kita Kuat!"'
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
          className: "flex w-full mt-4 lg:w-[45%] lg:mt-0 flex-col items-center gap-4",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
            className: "text-2xl font-black",
            children: "Sekretariat"
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "flex flex-wrap text-center w-[90%]",
            children: 'Gedung Giri Santika UPN "Veteran" Jawa Timur.Gn. Anyar, Kec. Gn. Anyar, Surabaya, Jawa Timur 60294'
          }), /*#__PURE__*/jsx_runtime_.jsx("iframe", {
            className: "w-[90%] h-[15rem] lg:w-full lg:h-[20rem] border-2 border-black",
            src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1978.5859369772957!2d112.7869155383215!3d-7.334585998168465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fab8189e09c1%3A0xe23a95446109db9!2sGedung%20Giri%20Santika%20UPN%20Veteran%20Jawa%20Timur!5e0!3m2!1sid!2sid!4v1696789341476!5m2!1sid!2sid",
            width: "450",
            height: "300",
            allowFullScreen: true,
            loading: "lazy",
            referrerPolicy: "no-referrer-when-downgrade"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
          className: "w-full flex flex-col items-center mt-10 mb-5 lg:items-start lg:mb-0 lg:mt-0 lg:w-[25%]",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
            className: "text-2xl font-black",
            children: "Follow Us!"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "mt-5 flex flex-col gap-3",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "group flex items-center gap-4",
              href: "#",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                className: "group-hover:animate-bounce",
                src: '/icons/VectorInstagram.svg',
                width: 20,
                height: 40,
                alt: 'UPN "Veteran" Jawa Timur '
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "group-hover:text-typedBlue",
                children: "@bemfasilkom.upnjatim"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "group flex items-center gap-4",
              href: "#",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                className: "group-hover:animate-bounce",
                src: '/icons/vectorLinkedin.svg',
                width: 20,
                height: 40,
                alt: 'UPN "Veteran" Jawa Timur '
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "group-hover:text-typedBlue",
                children: "@bemfasilkom.upnjatim"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "group flex items-center gap-4",
              href: "#",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                className: "group-hover:animate-bounce",
                src: '/icons/VectorTiktok.svg',
                width: 20,
                height: 40,
                alt: 'UPN "Veteran" Jawa Timur '
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "group-hover:text-typedBlue",
                children: "@bemfasilkom_upnvjt"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "group flex items-center gap-4",
              href: "#",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                className: "group-hover:animate-bounce",
                src: '/icons/vectorEmail.svg',
                width: 20,
                height: 40,
                alt: 'UPN "Veteran" Jawa Timur '
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "group-hover:text-typedBlue",
                children: "bemfasilkomupnvjt@gmail.com"
              })]
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex items-center justify-center text-center p-2",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: "\xA9 2023 All rights reserved, Bidang Penelitian dan Pengembangan BEM FASILKOM UPN \u201CVeteran\u201D Jawa Timur"
        })
      })]
    })
  });
};
;// CONCATENATED MODULE: ./pages/_app.tsx
'use client';




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












function MyApp({
  Component,
  pageProps,
  router
}) {
  const useRefScroll = (0,external_react_.useRef)();
  const {
    0: navbarBackgroundColor,
    1: setNavbarBackgroundColor
  } = (0,external_react_.useState)("#fff");
  const value = (0,external_react_.useMemo)(() => ({
    navbarBackgroundColor,
    setNavbarBackgroundColor
  }), [navbarBackgroundColor]);
  return /*#__PURE__*/jsx_runtime_.jsx(client_.Provider, {
    session: pageProps.session,
    children: /*#__PURE__*/jsx_runtime_.jsx(external_react_redux_.Provider, {
      store: store,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(navbar_background/* NavbarBackgroundContext.Provider */.s.Provider, {
        value: value,
        children: [/*#__PURE__*/jsx_runtime_.jsx(Navbar, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
          ref: useRefScroll,
          id: "root",
          className: "page-content",
          children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "footer",
          children: /*#__PURE__*/jsx_runtime_.jsx(Footer, {})
        })]
      })
    })
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 7930:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "styles_navbar__OA7C4",
	"navbar_mobile": "styles_navbar_mobile__JC3-a",
	"logo_navbar": "styles_logo_navbar__tOmgw",
	"navbar_mobile_branding": "styles_navbar_mobile_branding__fRGqd",
	"navbar_mobile_branding_text": "styles_navbar_mobile_branding_text__3dRxf",
	"navbar_mobile_hamburger": "styles_navbar_mobile_hamburger__3X7Z8",
	"navbar_mobile_menu": "styles_navbar_mobile_menu__atOYq",
	"navbar_mobile_menu__hidden": "styles_navbar_mobile_menu__hidden___9470",
	"navlink_mobile": "styles_navlink_mobile__1V_-7",
	"navlink_mobile_active": "styles_navlink_mobile_active__N5-l1",
	"navbar_desktop": "styles_navbar_desktop__38Ls8",
	"nav_desktop_container": "styles_nav_desktop_container__Q42Mz",
	"navlink": "styles_navlink__1ayAT",
	"navlink_container": "styles_navlink_container__2CziR",
	"navlink_active": "styles_navlink_active__v4QEp"
};


/***/ }),

/***/ 6139:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 8104:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,675,991,717], () => (__webpack_exec__(2313)));
module.exports = __webpack_exports__;

})();