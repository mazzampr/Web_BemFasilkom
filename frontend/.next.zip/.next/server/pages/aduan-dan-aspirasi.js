(() => {
var exports = {};
exports.id = 984;
exports.ids = [984];
exports.modules = {

/***/ 5372:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6251);
/* harmony import */ var _styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_auth_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8104);
/* harmony import */ var next_auth_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_client__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7687);
/* harmony import */ var _hooks_useDarkNavLinks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2698);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_DocumentHead__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3175);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_pageVisitSlices__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(761);















const AduanDanAspirasi = props => {
  var _session$user$email$s, _session$user, _session$user$email, _session$user$name, _session$user2, _session$user$email2, _session$user3;

  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
  const {
    session,
    listJurusan
  } = props;
  (0,_hooks_useDarkNavLinks__WEBPACK_IMPORTED_MODULE_4__/* .useDarkNavLinks */ .t)();
  const kodeJurusanFromNpm = (_session$user$email$s = session === null || session === void 0 ? void 0 : (_session$user = session.user) === null || _session$user === void 0 ? void 0 : (_session$user$email = _session$user.email) === null || _session$user$email === void 0 ? void 0 : _session$user$email.slice(2, 5)) !== null && _session$user$email$s !== void 0 ? _session$user$email$s : "";
  const selectedJurusanFromKode = kodeJurusanFromNpm === "081" ? "1" : kodeJurusanFromNpm === "082" ? "2" : kodeJurusanFromNpm === "083" ? "3" : "";
  const {
    0: nama,
    1: setNama
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)((_session$user$name = session === null || session === void 0 ? void 0 : (_session$user2 = session.user) === null || _session$user2 === void 0 ? void 0 : _session$user2.name) !== null && _session$user$name !== void 0 ? _session$user$name : "");
  const {
    0: email,
    1: setEmail
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)((_session$user$email2 = session === null || session === void 0 ? void 0 : (_session$user3 = session.user) === null || _session$user3 === void 0 ? void 0 : _session$user3.email) !== null && _session$user$email2 !== void 0 ? _session$user$email2 : "");
  const {
    0: pesan,
    1: setPesan
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: jurusan,
    1: setJurusan
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(selectedJurusanFromKode);
  const {
    0: tipeMasukan,
    1: setTipeMasukan
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Aduan");
  const {
    0: isSubmitting,
    1: setIsSubmitting
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    dispatch((0,_store_pageVisitSlices__WEBPACK_IMPORTED_MODULE_9__/* .setStatePageVisit */ .uK)({
      page: 'aduan-dan-aspirasi'
    }));
  }, [dispatch]);

  const submitHandler = event => {
    var _listJurusan$find;

    event.preventDefault();
    setIsSubmitting(true);
    const body = {
      nama,
      email,
      pesan,
      jurusan: {
        id: parseInt(jurusan),
        nama: (_listJurusan$find = listJurusan.find(currentJurusan => currentJurusan.id === parseInt(jurusan))) === null || _listJurusan$find === void 0 ? void 0 : _listJurusan$find.nama
      },
      tipe: tipeMasukan,
      status_aduan: 2
    };
    fetch(`${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}/aspirasi-dan-aduans`, {
      method: "post",
      body: JSON.stringify(body),
      headers: {
        "Content-Type": "application/json"
      }
    }).then(() => {
      fetch("/api/send-email", {
        method: "post",
        body: JSON.stringify(body),
        headers: {
          "Content-Type": "application/json"
        }
      });
    }).then(() => {
      alert(`Berhasil mengirimkan ${tipeMasukan.toLocaleLowerCase()}`);
      setPesan("");
    }).catch(() => {
      alert("Terdapat kesalahan, cek kembali form Anda atau coba beberapa saat lagi");
    }).finally(() => setIsSubmitting(false));
  };

  if (!session) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_5___default()), {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
          children: "Aduan dan Aspirasi | BEM Fasilkom UPN \"Veteran\" Jawa Timur"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().pre_login_screen),
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
          className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().login_text),
          children: ["Untuk mengakses halaman ini, silakan login dengan", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().google_upn_text),
            children: "akun Google UPN"
          }), " Anda terlebih dahulu"]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
          className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().sign_in_with_google_btn),
          onClick: () => (0,next_auth_client__WEBPACK_IMPORTED_MODULE_2__.signIn)("google", {
            callbackUrl: `/aduan-dan-aspirasi`
          }),
          children: "Login dengan Google"
        })]
      })]
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DocumentHead__WEBPACK_IMPORTED_MODULE_6__/* .DocumentHead */ .j, {
      pageTitle: "Aduan dan Aspirasi"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().page_container),
      style: {
        paddingTop: !session ? 0 : 80
      },
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
          className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title_main),
          children: "Aduan & Aspirasi"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
          className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title_sub),
          children: ["Hubungi kami dan salurkan aspirasi kalian", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().enter)
          }), "melalui formulir di bawah ini"]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().form_section),
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
          className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().form),
          onSubmit: submitHandler,
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().nama),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
              htmlFor: "nama",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().form_label),
              children: "Nama"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
              type: "text",
              id: "nama",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().input),
              value: nama,
              onChange: event => setNama(event.target.value),
              placeholder: "ex, Felliani Kurniawati",
              required: true,
              disabled: isSubmitting,
              readOnly: true
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().email),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
              htmlFor: "email",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().form_label),
              children: "Email"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
              type: "email",
              id: "email",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().input),
              value: email,
              onChange: event => setEmail(event.target.value),
              placeholder: "npm@student.upnjatim.ac.id",
              required: true,
              disabled: isSubmitting,
              readOnly: true
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().jurusan),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
              htmlFor: "jurusan",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().form_label),
              children: "Jurusan"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
              name: "jurusan",
              required: true,
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().select),
              onChange: event => setJurusan(event.target.value),
              disabled: isSubmitting || selectedJurusanFromKode !== "",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                value: "",
                disabled: true,
                children: "Pilihan Jurusan"
              }), listJurusan === null || listJurusan === void 0 ? void 0 : listJurusan.map(currentJurusan => {
                return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                  value: currentJurusan.kode_jurusan,
                  selected: jurusan === currentJurusan.id.toString(),
                  children: currentJurusan.nama
                }, currentJurusan.id);
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().radio_btn),
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().radio_input),
                type: "radio",
                name: "opsi",
                id: "aduan",
                value: "aduan",
                checked: tipeMasukan === "Aduan",
                onChange: () => setTipeMasukan("Aduan"),
                required: true
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                htmlFor: "aduan",
                className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().radio_label),
                children: "Aduan"
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().radio_input),
                type: "radio",
                name: "opsi",
                id: "aspirasi",
                value: "aspirasi",
                checked: tipeMasukan === "Aspirasi",
                onChange: () => setTipeMasukan("Aspirasi")
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                htmlFor: "aspirasi",
                className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().radio_label),
                children: "Aspirasi"
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().pesan),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
              htmlFor: "pesan",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().form_label),
              children: "Pesan"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
              name: "pesan",
              id: "pesan",
              className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().textarea),
              value: pesan,
              onChange: event => setPesan(event.target.value),
              placeholder: "Masukkan pesan",
              disabled: isSubmitting
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
            type: "submit",
            value: isSubmitting ? "Mengirim" : "Kirim",
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().submit_button),
            disabled: !nama || !email || !pesan || !jurusan || isSubmitting
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
          children: "atau"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_7__.default, {
          href: "/status-aduan",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: (_styles_AduanDanAspirasi_module_scss__WEBPACK_IMPORTED_MODULE_10___default().link_status_aduan),
            children: "Lihat Status Aduan"
          })
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
      onClick: () => (0,next_auth_client__WEBPACK_IMPORTED_MODULE_2__.signOut)(),
      className: "h-fit w-fit rounded-full border border-slate-200 text-white bg-red-600 p-2 px-5 shadow shadow-gray-500 hover:bg-white hover:border-red-600 hover:border-2 hover:font-bold hover:scale-[1.02] hover:text-red-600  mx-auto block ",
      children: "Log-Out"
    })]
  });
};

const getServerSideProps = async (context) => {
  const session = await (0,next_auth_client__WEBPACK_IMPORTED_MODULE_2__.getSession)(context);
  const listJurusan = await (await fetch(`${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}/jurusans`)).json();
  return {
    props: {
      session: session,
      listJurusan
    }
  };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AduanDanAspirasi);

/***/ }),

/***/ 6251:
/***/ ((module) => {

// Exports
module.exports = {
	"page_container": "AduanDanAspirasi_page_container__38HMW",
	"google_upn_text": "AduanDanAspirasi_google_upn_text__2GD0K",
	"link_status_aduan": "AduanDanAspirasi_link_status_aduan__29840",
	"checkbtn": "AduanDanAspirasi_checkbtn__rO1sf",
	"textarea": "AduanDanAspirasi_textarea__zZ80o",
	"submit_button": "AduanDanAspirasi_submit_button__12QDE",
	"spinner": "AduanDanAspirasi_spinner__1VLDT",
	"pre_login_screen": "AduanDanAspirasi_pre_login_screen__2OLp9",
	"login_text": "AduanDanAspirasi_login_text__23Ljh",
	"sign_in_with_google_btn": "AduanDanAspirasi_sign_in_with_google_btn__P_iMr",
	"title": "AduanDanAspirasi_title__2w0ce",
	"enter": "AduanDanAspirasi_enter__23K-w",
	"title_main": "AduanDanAspirasi_title_main__22dat",
	"title_sub": "AduanDanAspirasi_title_sub__1Icox",
	"form_section": "AduanDanAspirasi_form_section__2JuZe",
	"form": "AduanDanAspirasi_form__2vfKT",
	"input": "AduanDanAspirasi_input__1ItRa",
	"form_label": "AduanDanAspirasi_form_label__15Zml",
	"select": "AduanDanAspirasi_select__N8dBx",
	"nama": "AduanDanAspirasi_nama__2nWS1",
	"email": "AduanDanAspirasi_email__3wxS9",
	"jurusan": "AduanDanAspirasi_jurusan__1lx8x",
	"pesan": "AduanDanAspirasi_pesan__26kae",
	"radio_btn": "AduanDanAspirasi_radio_btn__2yEU7",
	"radio_input": "AduanDanAspirasi_radio_input__k6uox",
	"label": "AduanDanAspirasi_label__1vWzz",
	"radio_label": "AduanDanAspirasi_radio_label__1xdGh"
};


/***/ }),

/***/ 6139:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 8104:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,991,196], () => (__webpack_exec__(5372)));
module.exports = __webpack_exports__;

})();