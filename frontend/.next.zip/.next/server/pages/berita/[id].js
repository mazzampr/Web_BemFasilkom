(() => {
var exports = {};
exports.id = 832;
exports.ids = [832];
exports.modules = {

/***/ 3813:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8477);
/* harmony import */ var _styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8354);
/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_error__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3703);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7687);
/* harmony import */ var _hooks_useDarkNavLinks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2698);
/* harmony import */ var _components_DocumentHead__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3175);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3879);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_pageVisitSlices__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(761);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];














const NewsPage = props => {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
  dispatch((0,_store_pageVisitSlices__WEBPACK_IMPORTED_MODULE_8__/* .setStatePageVisit */ .uK)({
    page: 'Berita'
  }));
  const {
    errorCode,
    detailBerita,
    listBerita
  } = props;
  (0,_hooks_useDarkNavLinks__WEBPACK_IMPORTED_MODULE_4__/* .useDarkNavLinks */ .t)();

  if (errorCode || !detailBerita) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_error__WEBPACK_IMPORTED_MODULE_1___default()), {
      statusCode: errorCode,
      title: "Tidak dapat menemukan berita"
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DocumentHead__WEBPACK_IMPORTED_MODULE_5__/* .DocumentHead */ .j, {
      pageTitle: "Berita"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
      className: (_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default().main),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-fit h-fit flex flex-col  lg:flex-row mt-3",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
          className: "lg:w-[70%]",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: (_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["head-news"]),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
              className: "w-[106px] h-[34px] rounded-[10px] bg-[#F2DECE] text-left mt-10 text-center flex items-center justify-center text-[#FA6D01]",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: detailBerita.category.category
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
              className: (_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["news-title"]),
              children: detailBerita.judul
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
              className: (_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["news-info-date"]),
              children: [date_fns__WEBPACK_IMPORTED_MODULE_6__.format(new Date(detailBerita.created_at), "d MMMM yyyy"), " ", "\u2022 By ", detailBerita.author.firstname]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["img-container"]),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
              src: `${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}${detailBerita.cover.url}`,
              alt: ""
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("article", {
            className: (_styles_NewsDetail_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["news-content"]),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__.default, {
              transformImageUri: (src, alt, title) => _constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5 + src,
              children: detailBerita.konten
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
          className: "  mt-10  sm:mt-[4em] lg:mt-9 w-[80%]  mx-auto lg:w-[30%] lg:p-2",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "font-[700] text-[19px] md:text-[24px] ml-auto md:mb-4 lg:mb-0",
            children: "Artikel Terbaru"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-[250px] lg:h-fit overflow-y-scroll lg:overflow-y-visible flex flex-col",
            children: listBerita.map((article, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_9__.default, {
                href: `/berita/${article.id}`,
                passHref: true,
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
                  className: "flex    w-[100%] mx-auto mt-3 h-fit cursor-pointer ",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "h-[65px] w-[65px] md:h-[120px] object-fit md:w-[120px] lg:w-[65px] lg:h-[65px]  bg-slate-100 rounded-[10px] mr-3 ",
                    src: `${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}${article.cover.url}`,
                    alt: ""
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "text-[0.9rem] sm:text-[1.1rem]  md:text-[1.65em] lg:text-[14px] mt-1",
                    children: article.judul
                  })]
                })
              }, i)
            }))
          })]
        })]
      })
    })]
  });
};

const getServerSideProps = async context => {
  var _context$params;

  const res = await fetch(`${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}/beritas/${(_context$params = context.params) === null || _context$params === void 0 ? void 0 : _context$params.id}`); // const res1 = await fetch(`${API_URL}/beritas/${context.params?.id}`);

  const [beritaList, beritaCount] = await Promise.all([await (await fetch(`${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}/beritas?_sort=created_at:DESC&_start=0&_limit=6`)).json(), await (await fetch(`${_constants__WEBPACK_IMPORTED_MODULE_3__/* .API_URL */ .T5}/beritas/count`)).json()]);
  const errorCode = res.ok ? false : res.status;
  const detailBerita = res.status === 404 ? null : await res.json();
  console.log(beritaList);
  return {
    props: {
      errorCode,
      detailBerita,
      listBerita: beritaList
    }
  };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewsPage);
});

/***/ }),

/***/ 8477:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "NewsDetail_main__1gFbu",
	"head-news": "NewsDetail_head-news__mH0nb",
	"border-shape": "NewsDetail_border-shape__2Jv1f",
	"border-shape-inside": "NewsDetail_border-shape-inside__HWduH",
	"news-title": "NewsDetail_news-title__PpkvL",
	"news-info-date": "NewsDetail_news-info-date__3FOVY",
	"news-info-author": "NewsDetail_news-info-author__2KJnk",
	"img-container": "NewsDetail_img-container__usjkz",
	"news-content": "NewsDetail_news-content__zhAWC",
	"content-quote": "NewsDetail_content-quote__3R2G0",
	"border-shape-down": "NewsDetail_border-shape-down__1uPnR"
};


/***/ }),

/***/ 6139:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3879:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 8354:
/***/ ((module) => {

"use strict";
module.exports = require("next/error");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 3703:
/***/ ((module) => {

"use strict";
module.exports = import("react-markdown");;

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,991,196], () => (__webpack_exec__(3813)));
module.exports = __webpack_exports__;

})();