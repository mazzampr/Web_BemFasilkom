"use strict";
(() => {
var exports = {};
exports.id = 957;
exports.ids = [957];
exports.modules = {

/***/ 7687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T5": () => (/* binding */ API_URL),
/* harmony export */   "Yi": () => (/* binding */ EMAIL_BEM)
/* harmony export */ });
/* unused harmony export SELF_URL */
// export const API_URL = "https://web-bem-testing.herokuapp.com";
// export const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_URL = "http://localhost:1337"; // export const SELF_URL = "https://website-bem.vercel.app";

const SELF_URL = process.env.SELF_URL;
const EMAIL_BEM = "bem.fasilkom@upnjatim.ac.id";

/***/ }),

/***/ 380:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "nodemailer"
const external_nodemailer_namespaceObject = require("nodemailer");
var external_nodemailer_default = /*#__PURE__*/__webpack_require__.n(external_nodemailer_namespaceObject);
;// CONCATENATED MODULE: external "googleapis"
const external_googleapis_namespaceObject = require("googleapis");
// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(7687);
;// CONCATENATED MODULE: ./pages/api/send-email.ts
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction



async function handler(req, res) {
  if (req.method === "POST") {
    try {
      const body = req.body;
      const OAuth2 = external_googleapis_namespaceObject.google.auth.OAuth2;
      const oauth2Client = new OAuth2({
        clientId: "650270545823-l7plhbiusbfcbtgupsndkhcl2gfh7tiu.apps.googleusercontent.com",
        clientSecret: "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",
        redirectUri: `/aduan-dan-aspirasi`
      });
      oauth2Client.setCredentials({
        refresh_token: process.env.OAUTH2_REFRESH_TOKEN
      });
      const accessToken = await oauth2Client.getAccessToken();
      const transporter = external_nodemailer_default().createTransport({
        // @ts-ignore
        service: "gmail",
        auth: {
          type: "OAuth2",
          user: constants/* EMAIL_BEM */.Yi,
          clientId: process.env.OAUTH2_CLIENT_ID,
          clientSecret: process.env.OAUTH2_CLIENT_SECRET,
          refreshToken: process.env.OAUTH2_REFRESH_TOKEN,
          accessToken: accessToken
        },
        secure: true,
        tls: {
          rejectUnauthorized: false
        }
      });
      const messageInfo = transporter.sendMail({
        from: constants/* EMAIL_BEM */.Yi,
        to: constants/* EMAIL_BEM */.Yi,
        subject: `Terdapat ${body.tipe} Baru!`,
        html: `
          <h3>${body.tipe} Baru di Situs Web BEM FASILKOM UPN "Veteran" Jawa Timur</h3>
          <p>Nama: ${body.nama}</p>
          <p>Email: ${body.email}</p>
          <p>Program studi: ${body.jurusan.nama}</p>
          <p>Pesan:</p>
          <p>${body.pesan}</p>
        `
      });
      res.status(200).json({
        accepted: (await messageInfo).accepted
      });
    } catch (error) {
      console.log("error", error);
      res.status(500).json({
        error
      });
    }
  }
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(380));
module.exports = __webpack_exports__;

})();